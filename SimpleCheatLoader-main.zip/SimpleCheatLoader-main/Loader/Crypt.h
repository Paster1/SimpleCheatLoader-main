#pragma once
#include <Windows.h>

void XOR(BYTE* data, DWORD size);