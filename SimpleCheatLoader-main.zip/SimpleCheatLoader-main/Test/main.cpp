#include <Windows.h>
#include <stdio.h>

int main()
{
	printf("Hello from Test ^^");
	while(true){}
}